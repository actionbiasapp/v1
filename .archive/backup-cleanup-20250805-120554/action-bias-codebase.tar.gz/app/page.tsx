import PortfolioDashboard from './components/PortfolioDashboard';

export default function Home() {
  return <PortfolioDashboard />;
}